/* *****************************************************************
 * @SID      610575
 * @Author   ERDENEBAYAR CHINBAT
 * @Created  Nov 03, 2019
 ******************************************************************/

package W1D3;

public class InMapperWordCount {

    private Mapper mapper;
    private Reducer reducer;

    public InMapperWordCount(int m, int r){
        System.out.println("In Mapper Word Count:");
//        mapper = new mapper[m];
//        for(int i=0;i<mappers.length;i++){
//            mappers[i]= new MyMapper(filePath + "./src/W1D1/file + " i " + .txt");
//        }
//        reducers = new MyReducer[r];
//        for(int i=0;i<reducers.length;i++){
//            reducers[i]=new MyReducer();
//        }
    }

    public void print(){
        System.out.println("Mapper output:");
//        for(MyMapper m: mappers){
//            System.out.println("Mapper output" );
//            m.map().stream().sorted().forEach(System.out::println);
//        }
    }
}